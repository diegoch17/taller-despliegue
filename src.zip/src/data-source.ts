import { DataSource } from "typeorm";
import { User } from "./users/entities/user.entity";

export const AppDataSource = new DataSource({
    type: "postgres", // o mysql, mariadb, sqlite, etc.
    host: "localhost",
    port: 5432,
    username: "root",
    password: "rootpassword",
    database: "auth_db",
    synchronize: false, // ¡SIEMPRE en false cuando usas migraciones!
    logging: true,
    entities: [User], // o "src/entity/**/*.ts"
    migrations: ["src/migration/**/*.ts"],
    subscribers: [],
});